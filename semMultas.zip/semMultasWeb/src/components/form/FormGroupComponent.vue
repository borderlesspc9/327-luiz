<script setup lang="ts">
</script>
<template>
    <div class="form-group">
        <slot></slot>
    </div>
</template>