<script>
</script>

<template>
    <div class="container-card">
        <slot></slot>
    </div>
</template>