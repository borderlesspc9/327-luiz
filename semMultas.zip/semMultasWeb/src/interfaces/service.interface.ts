export interface Service {
    id?: number;
    name: string;
    process_fields: string;
    slug?: string;
}