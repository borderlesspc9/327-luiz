export interface Permission {
    id?: number;
    name: string;
    slug?: string;
}