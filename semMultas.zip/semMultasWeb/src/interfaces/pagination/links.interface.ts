export interface Link {
    url: string | null;
    label: string;
    active: boolean;
}