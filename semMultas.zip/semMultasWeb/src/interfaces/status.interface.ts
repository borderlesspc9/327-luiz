export interface Status {
    id?: number;
    title: string;
    color: string;
    slug?: string;
}
